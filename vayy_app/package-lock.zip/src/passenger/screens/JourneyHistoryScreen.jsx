import React from "react";

import MvpScreen from "../../shared/components/common/MvpScreen";

export default function JourneyHistoryScreen() {
  return <MvpScreen title="Journey history" subtitle="Auto flags and Bike ride history will appear here." />;
}

