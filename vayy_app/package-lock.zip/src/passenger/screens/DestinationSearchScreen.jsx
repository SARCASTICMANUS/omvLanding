import React from "react";

import MvpScreen from "../../shared/components/common/MvpScreen";

export default function DestinationSearchScreen({ navigation }) {
  return (
    <MvpScreen
      title="Destination search"
      subtitle="Search destination and match the nearest pickup and destination stops."
      actions={[{ label: "Show routes", onPress: () => navigation.navigate("RouteResultsScreen") }]}
    />
  );
}

