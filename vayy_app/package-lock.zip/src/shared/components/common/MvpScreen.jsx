import React from "react";
import { SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";

import COLORS from "../../constants/colors";
import SPACING from "../../constants/spacing";
import VayyButton from "./VayyButton";

export default function MvpScreen({ title, subtitle, actions = [], children }) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>{title}</Text>
          {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        </View>
        {children}
        {actions.length ? (
          <View style={styles.actions}>
            {actions.map((action) => (
              <VayyButton
                key={action.label}
                label={action.label}
                onPress={action.onPress}
                variant={action.variant || "primary"}
                fullWidth
              />
            ))}
          </View>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: COLORS.background,
    flex: 1,
  },
  content: {
    gap: SPACING.base,
    padding: SPACING.lg,
    paddingBottom: 92,
  },
  header: {
    gap: SPACING.xs,
  },
  title: {
    color: COLORS.text,
    fontSize: 26,
    fontWeight: "900",
  },
  subtitle: {
    color: COLORS.textMuted,
    fontSize: 14,
    lineHeight: 20,
  },
  actions: {
    gap: SPACING.sm,
  },
});

