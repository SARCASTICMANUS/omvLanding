const BASE_FARES = {
  AUTO: 20,
  BIKE: 35,
};

const PER_KM_FARES = {
  AUTO: 8,
  BIKE: 12,
};

export const estimateFare = async (distance = 0, mode = "AUTO") => {
  const normalizedMode = String(mode).toUpperCase();
  const distanceKm = Number(distance) > 100 ? Number(distance) / 1000 : Number(distance) || 0;
  const baseFare = BASE_FARES[normalizedMode] || BASE_FARES.AUTO;
  const perKmFare = PER_KM_FARES[normalizedMode] || PER_KM_FARES.AUTO;

  return {
    amount: Math.max(baseFare, Math.round(baseFare + distanceKm * perKmFare)),
    currency: "INR",
    distanceKm: Number(distanceKm.toFixed(2)),
    mode: normalizedMode,
  };
};

export default {
  estimateFare,
};

