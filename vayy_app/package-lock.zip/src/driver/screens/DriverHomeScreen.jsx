import React from "react";

import MvpScreen from "../../shared/components/common/MvpScreen";

export default function DriverHomeScreen({ navigation }) {
  return (
    <MvpScreen
      title="Driver"
      subtitle="Select Auto for fixed-route alerts or Bike for direct ride requests."
      actions={[
        { label: "Select vehicle mode", onPress: () => navigation.navigate("VehicleSelectionScreen") },
        { label: "Passenger alerts", onPress: () => navigation.navigate("PassengerAlertsScreen"), variant: "outline" },
        { label: "Bike requests", onPress: () => navigation.navigate("BikeRequestScreen"), variant: "outline" },
      ]}
    />
  );
}

