import React from "react";

import MvpScreen from "../../shared/components/common/MvpScreen";

export default function DriverTripHistoryScreen() {
  return <MvpScreen title="Trip history" subtitle="Completed Auto duty and Bike ride records will appear here." />;
}

