import React from "react";
import { useDispatch } from "react-redux";

import MvpScreen from "../../shared/components/common/MvpScreen";
import { setVehicleMode } from "../../store/slices/vehicleModeSlice";

export default function VehicleSelectionScreen({ navigation }) {
  const dispatch = useDispatch();

  return (
    <MvpScreen
      title="Vehicle mode"
      subtitle="Auto receives passenger waiting notifications. Bike receives accept or decline ride cards."
      actions={[
        {
          label: "Drive Auto",
          onPress: () => {
            dispatch(setVehicleMode("AUTO"));
            navigation.navigate("RouteCreationScreen");
          },
        },
        {
          label: "Drive Bike",
          onPress: () => {
            dispatch(setVehicleMode("BIKE"));
            navigation.navigate("BikeRequestScreen");
          },
          variant: "outline",
        },
      ]}
    />
  );
}

