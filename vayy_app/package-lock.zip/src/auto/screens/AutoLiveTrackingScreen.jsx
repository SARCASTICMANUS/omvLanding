import React from "react";

import AutoTrackingMap from "../../tracking/components/AutoTrackingMap";
import MvpScreen from "../../shared/components/common/MvpScreen";

export default function AutoLiveTrackingScreen() {
  return (
    <MvpScreen title="Auto live tracking" subtitle="Auto route, stops, and live vehicle position.">
      <AutoTrackingMap />
    </MvpScreen>
  );
}

