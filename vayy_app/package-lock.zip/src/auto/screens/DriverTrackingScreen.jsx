import React from "react";

import MvpScreen from "../../shared/components/common/MvpScreen";
import AutoTrackingMap from "../../tracking/components/AutoTrackingMap";
import VerificationCodeCard from "../../handshake/components/VerificationCodeCard";

export default function DriverTrackingScreen() {
  return (
    <MvpScreen title="Driver tracking" subtitle="Live route map plus Bike handshake entry when assigned.">
      <AutoTrackingMap />
      <VerificationCodeCard status="PENDING" />
    </MvpScreen>
  );
}

