import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  savedRoutes: [],
  selectedRouteId: null,
};

const routeLibrarySlice = createSlice({
  name: "routeLibrary",
  initialState,
  reducers: {
    setSavedRoutes: (state, action) => {
      state.savedRoutes = action.payload || [];
    },
    saveRouteToLibrary: (state, action) => {
      const route = action.payload;
      state.savedRoutes = [route, ...state.savedRoutes.filter((item) => item.routeId !== route.routeId)];
    },
    deleteRouteFromLibrary: (state, action) => {
      state.savedRoutes = state.savedRoutes.filter((route) => route.routeId !== action.payload);
    },
    selectLibraryRoute: (state, action) => {
      state.selectedRouteId = action.payload;
      const route = state.savedRoutes.find((item) => item.routeId === action.payload);
      if (route) route.lastUsedAt = new Date().toISOString();
    },
  },
});

export const {
  deleteRouteFromLibrary,
  saveRouteToLibrary,
  selectLibraryRoute,
  setSavedRoutes,
} = routeLibrarySlice.actions;

export default routeLibrarySlice.reducer;

