import React from "react";

import RouteCard from "../components/RouteCard";
import MvpScreen from "../../shared/components/common/MvpScreen";

export default function RouteSelectionScreen({ navigation }) {
  return (
    <MvpScreen
      title="Route selection"
      subtitle="Start Auto duty on the selected route and listen for passenger flags."
      actions={[{ label: "Start tracking", onPress: () => navigation.navigate("DriverTrackingScreen") }]}
    >
      <RouteCard route={{ routeName: "Selected Auto Route", start: "Campus Gate", end: "City Metro", distanceText: "5 km", durationText: "18 min" }} />
    </MvpScreen>
  );
}

