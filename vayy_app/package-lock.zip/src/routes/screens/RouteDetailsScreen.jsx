import React from "react";

import RouteCard from "../components/RouteCard";
import MvpScreen from "../../shared/components/common/MvpScreen";

export default function RouteDetailsScreen({ navigation }) {
  return (
    <MvpScreen
      title="Route details"
      subtitle="Review pickup stop, destination stop, fare estimate, and route status."
      actions={[{ label: "Raise hand", onPress: () => navigation.navigate("RaiseHandScreen") }]}
    >
      <RouteCard route={{ routeName: "Green Line Auto", start: "Campus Gate", end: "City Metro", distanceText: "5 km", durationText: "18 min" }} />
    </MvpScreen>
  );
}

