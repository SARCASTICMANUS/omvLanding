import React, { useState } from "react";
import { useDispatch } from "react-redux";

import MvpScreen from "../../shared/components/common/MvpScreen";
import AutoTrackingMap from "../../tracking/components/AutoTrackingMap";
import { saveRoute } from "../services/routeLibraryService";
import { saveRouteToLibrary } from "../routeLibrarySlice";
import { setRoutePreview } from "../routeSlice";

const previewRoute = {
  routeId: "preview-auto-route",
  routeName: "Driver Auto Route",
  startLocation: { name: "Campus Gate", longitude: 77.5946, latitude: 12.9716 },
  endLocation: { name: "City Metro", longitude: 77.6146, latitude: 12.9866 },
  distance: 5200,
  duration: 1080,
  geometry: [
    [77.5946, 12.9716],
    [77.6046, 12.9816],
    [77.6146, 12.9866],
  ],
};

export default function RouteCreationScreen({ navigation }) {
  const dispatch = useDispatch();
  const [saved, setSaved] = useState(false);

  const handlePreview = () => {
    dispatch(setRoutePreview(previewRoute));
  };

  const handleSave = async () => {
    const route = await saveRoute(previewRoute);
    dispatch(saveRouteToLibrary(route));
    setSaved(true);
  };

  return (
    <MvpScreen
      title="Create route"
      subtitle={saved ? "Route saved to library." : "Generate an OSRM route preview, then save it for Auto duty."}
      actions={[
        { label: "Generate preview", onPress: handlePreview, variant: "outline" },
        { label: "Save route", onPress: handleSave },
        { label: "Open route library", onPress: () => navigation.navigate("RouteLibraryScreen"), variant: "outline" },
      ]}
    >
      <AutoTrackingMap routeCoordinates={previewRoute.geometry} />
    </MvpScreen>
  );
}

