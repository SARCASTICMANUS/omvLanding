import React from "react";

import RouteCard from "../components/RouteCard";
import MvpScreen from "../../shared/components/common/MvpScreen";

const sampleRoute = {
  routeName: "Green Line Auto",
  start: "Campus Gate",
  end: "City Metro",
  distanceText: "5 km",
  durationText: "18 min",
};

export default function RouteResultsScreen({ navigation }) {
  return (
    <MvpScreen title="Route results" subtitle="Fixed-route Auto options ordered by nearby pickup stop.">
      <RouteCard route={sampleRoute} onPress={() => navigation.navigate("RouteDetailsScreen")} />
    </MvpScreen>
  );
}

