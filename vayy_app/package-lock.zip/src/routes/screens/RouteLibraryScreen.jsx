import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import RouteLibraryCard from "../components/RouteLibraryCard";
import MvpScreen from "../../shared/components/common/MvpScreen";
import { getSavedRoutes } from "../services/routeLibraryService";
import { selectLibraryRoute, setSavedRoutes } from "../routeLibrarySlice";

const fallbackRoute = {
  routeId: "fallback-route",
  routeName: "Green Line Auto",
  startLocation: "Campus Gate",
  endLocation: "City Metro",
  distance: 5200,
  duration: 1080,
};

export default function RouteLibraryScreen({ navigation }) {
  const dispatch = useDispatch();
  const routes = useSelector((state) => state.routeLibrary.savedRoutes);

  useEffect(() => {
    getSavedRoutes().then((items) => dispatch(setSavedRoutes(items)));
  }, [dispatch]);

  const visibleRoutes = routes.length ? routes : [fallbackRoute];

  return (
    <MvpScreen title="Route library" subtitle="Saved Auto routes for the current driver.">
      {visibleRoutes.map((route) => (
        <RouteLibraryCard
          key={route.routeId}
          route={route}
          onSelect={() => {
            dispatch(selectLibraryRoute(route.routeId));
            navigation.navigate("RouteSelectionScreen");
          }}
        />
      ))}
    </MvpScreen>
  );
}

