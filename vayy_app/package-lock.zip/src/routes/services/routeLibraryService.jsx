import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "vayy.routeLibrary";

export const getSavedRoutes = async () => {
  const rawRoutes = await AsyncStorage.getItem(STORAGE_KEY);
  return rawRoutes ? JSON.parse(rawRoutes) : [];
};

export const saveRoute = async (routeData) => {
  const routes = await getSavedRoutes();
  const route = {
    ...routeData,
    routeId: routeData.routeId || `route-${Date.now()}`,
    createdAt: routeData.createdAt || new Date().toISOString(),
    lastUsedAt: routeData.lastUsedAt || null,
  };
  const nextRoutes = [route, ...routes.filter((item) => item.routeId !== route.routeId)];
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nextRoutes));
  return route;
};

export const deleteRoute = async (routeId) => {
  const routes = await getSavedRoutes();
  const nextRoutes = routes.filter((route) => route.routeId !== routeId);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nextRoutes));
  return routeId;
};

export default {
  saveRoute,
  getSavedRoutes,
  deleteRoute,
};

