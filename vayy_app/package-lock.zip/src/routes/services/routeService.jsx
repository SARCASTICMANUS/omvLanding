import { decodePolyline } from "../../shared/utils/polyline";

const OSRM_URL = "https://router.project-osrm.org/route/v1/driving";

const toCoordinate = (point) => {
  if (Array.isArray(point)) {
    return { longitude: Number(point[0]), latitude: Number(point[1]) };
  }

  return {
    longitude: Number(point?.longitude ?? point?.lng ?? point?.lon),
    latitude: Number(point?.latitude ?? point?.lat),
    name: point?.name,
  };
};

const assertCoordinate = (point, label) => {
  if (!Number.isFinite(point.longitude) || !Number.isFinite(point.latitude)) {
    throw new Error(`${label} must include valid latitude and longitude`);
  }
};

const buildStops = (coordinates, start, end) => {
  if (!coordinates.length) return [];
  const middleIndex = Math.floor(coordinates.length / 2);
  const candidates = [coordinates[0], coordinates[middleIndex], coordinates[coordinates.length - 1]];

  return candidates.map(([longitude, latitude], index) => ({
    stopId: `stop-${index + 1}`,
    name: index === 0 ? start.name || "Start stop" : index === candidates.length - 1 ? end.name || "Destination stop" : "Mid-route stop",
    latitude,
    longitude,
    order: index,
  }));
};

export const generateRoute = async (start, end) => {
  const startCoord = toCoordinate(start);
  const endCoord = toCoordinate(end);
  assertCoordinate(startCoord, "Start");
  assertCoordinate(endCoord, "End");

  const response = await fetch(
    `${OSRM_URL}/${startCoord.longitude},${startCoord.latitude};${endCoord.longitude},${endCoord.latitude}?overview=full&geometries=polyline&steps=false`,
  );

  if (!response.ok) {
    throw new Error("Unable to generate route");
  }

  const payload = await response.json();
  const route = payload?.routes?.[0];
  if (!route?.geometry) {
    throw new Error("OSRM did not return route geometry");
  }

  const coordinates = decodePolyline(route.geometry);

  return {
    routeId: `route-${Date.now()}`,
    geometry: coordinates,
    stops: buildStops(coordinates, startCoord, endCoord),
    distance: route.distance,
    duration: route.duration,
    startLocation: startCoord,
    endLocation: endCoord,
  };
};

export default {
  generateRoute,
};

