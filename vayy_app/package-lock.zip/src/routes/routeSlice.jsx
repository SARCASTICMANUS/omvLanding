import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  activeRoute: null,
  routePreview: null,
  routeList: [],
  status: "idle",
  error: null,
};

const routeSlice = createSlice({
  name: "route",
  initialState,
  reducers: {
    setRoutePreview: (state, action) => {
      state.routePreview = action.payload;
    },
    setActiveRoute: (state, action) => {
      state.activeRoute = action.payload;
    },
    setRouteList: (state, action) => {
      state.routeList = action.payload || [];
    },
    addRoute: (state, action) => {
      state.routeList.unshift(action.payload);
    },
    clearRoutePreview: (state) => {
      state.routePreview = null;
    },
    setRouteStatus: (state, action) => {
      state.status = action.payload;
    },
    setRouteError: (state, action) => {
      state.error = action.payload;
    },
  },
});

export const {
  addRoute,
  clearRoutePreview,
  setActiveRoute,
  setRouteError,
  setRouteList,
  setRoutePreview,
  setRouteStatus,
} = routeSlice.actions;

export default routeSlice.reducer;

