import React from "react";
import { StyleSheet, Text, View } from "react-native";

import COLORS from "../../shared/constants/colors";
import SPACING from "../../shared/constants/spacing";
import VayyButton from "../../shared/components/common/VayyButton";
import VayyCard from "../../shared/components/common/VayyCard";

export default function RouteCard({ route = {}, onPress }) {
  return (
    <VayyCard style={styles.card}>
      <Text style={styles.title}>{route.routeName || route.name || "VAYY route"}</Text>
      <View style={styles.row}>
        <Text style={styles.label}>Start</Text>
        <Text style={styles.value}>{route.startLocation?.name || route.start || "Origin stop"}</Text>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>End</Text>
        <Text style={styles.value}>{route.endLocation?.name || route.end || "Destination stop"}</Text>
      </View>
      <View style={styles.metrics}>
        <Text style={styles.metric}>{route.distanceText || `${Math.round((route.distance || 0) / 1000 || 4)} km`}</Text>
        <Text style={styles.metric}>{route.durationText || `${Math.round((route.duration || 0) / 60 || 18)} min`}</Text>
      </View>
      {onPress ? <VayyButton label="View route" onPress={onPress} variant="outline" size="sm" /> : null}
    </VayyCard>
  );
}

const styles = StyleSheet.create({
  card: {
    gap: SPACING.sm,
  },
  title: {
    color: COLORS.text,
    fontSize: 17,
    fontWeight: "800",
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: SPACING.base,
  },
  label: {
    color: COLORS.textMuted,
    fontSize: 13,
  },
  value: {
    color: COLORS.textSecondary,
    flex: 1,
    fontSize: 13,
    fontWeight: "700",
    textAlign: "right",
  },
  metrics: {
    flexDirection: "row",
    gap: SPACING.sm,
  },
  metric: {
    backgroundColor: COLORS.background,
    borderRadius: 8,
    color: COLORS.textSecondary,
    fontSize: 13,
    fontWeight: "700",
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
  },
});

