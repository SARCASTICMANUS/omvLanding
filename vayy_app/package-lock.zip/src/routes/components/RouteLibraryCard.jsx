import React from "react";
import { StyleSheet, Text, View } from "react-native";

import COLORS from "../../shared/constants/colors";
import SPACING from "../../shared/constants/spacing";
import VayyButton from "../../shared/components/common/VayyButton";
import VayyCard from "../../shared/components/common/VayyCard";

const formatDate = (value) => (value ? new Date(value).toLocaleDateString() : "Never used");

export default function RouteLibraryCard({ route = {}, onSelect }) {
  return (
    <VayyCard style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.title}>{route.routeName || "Saved route"}</Text>
        <Text style={styles.meta}>{formatDate(route.lastUsedAt)}</Text>
      </View>
      <Text style={styles.path}>
        {route.startLocation?.name || route.startLocation || "Start"} to {route.endLocation?.name || route.endLocation || "End"}
      </Text>
      <Text style={styles.meta}>
        {route.distance ? `${Math.round(route.distance / 1000)} km` : "--"} •{" "}
        {route.duration ? `${Math.round(route.duration / 60)} min` : "--"}
      </Text>
      <VayyButton label="Select route" onPress={onSelect} size="sm" />
    </VayyCard>
  );
}

const styles = StyleSheet.create({
  card: {
    gap: SPACING.sm,
  },
  header: {
    alignItems: "flex-start",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: SPACING.base,
  },
  title: {
    color: COLORS.text,
    flex: 1,
    fontSize: 16,
    fontWeight: "800",
  },
  path: {
    color: COLORS.textSecondary,
    fontSize: 14,
    fontWeight: "700",
  },
  meta: {
    color: COLORS.textMuted,
    fontSize: 12,
    fontWeight: "600",
  },
});

