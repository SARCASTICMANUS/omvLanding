import React from "react";
import { Text, View } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";

import COLORS from "../shared/constants/colors";
import AllBusesPage from "../routes/screens/AllBusesPage";
import PassengerRouteList from "../routes/screens/PassengerRouteList";
import PassengerLiveTracking from "../tracking/screens/PassengerLiveTracking";
import PassengerStopsTimeline from "../routes/screens/PassengerStopsTimeline";
import PassengerTripPlanner from "../passenger/screens/PassengerTripPlanner";
import AutoLiveTrackingScreen from "../auto/screens/AutoLiveTrackingScreen";
import BikeBookingScreen from "../bike/screens/BikeBookingScreen";
import BikeSearchingScreen from "../bike/screens/BikeSearchingScreen";
import BikeTrackingScreen from "../bike/screens/BikeTrackingScreen";
import DestinationSearchScreen from "../passenger/screens/DestinationSearchScreen";
import JourneyHistoryScreen from "../passenger/screens/JourneyHistoryScreen";
import PassengerHomeScreen from "../passenger/screens/PassengerHomeScreen";
import RaiseHandScreen from "../handshake/screens/RaiseHandScreen";
import RouteDetailsScreen from "../routes/screens/RouteDetailsScreen";
import RouteResultsScreen from "../routes/screens/RouteResultsScreen";

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const PlaceholderScreen = ({ route }) => (
  <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
    <Text>{route.name}</Text>
  </View>
);

function PassengerTabs() {
  return (
    <Tab.Navigator
      initialRouteName="PassengerTripPlanner"
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.textLight,
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: "700",
        },
        tabBarStyle: {
          backgroundColor: COLORS.white,
          borderTopColor: COLORS.border,
          borderTopLeftRadius: 12,
          borderTopRightRadius: 12,
          height: 58,
          paddingBottom: 8,
          paddingTop: 4,
          position: "absolute",
        },
      }}
    >
      <Tab.Screen
        name="PassengerHome"
        component={PassengerHomeScreen}
        options={{ title: "Home", tabBarIcon: ({ color }) => <Text style={{ color }}>H</Text> }}
      />
      <Tab.Screen
        name="PassengerRoutes"
        component={AllBusesPage}
        options={{ title: "Routes", tabBarIcon: ({ color }) => <Text style={{ color }}>R</Text> }}
      />
      <Tab.Screen
        name="PassengerTripPlanner"
        component={PassengerTripPlanner}
        options={{ title: "Live Map", tabBarIcon: ({ color }) => <Text style={{ color }}>M</Text> }}
      />
      <Tab.Screen
        name="PassengerAlerts"
        component={PlaceholderScreen}
        options={{ title: "Alerts", tabBarIcon: ({ color }) => <Text style={{ color }}>A</Text> }}
      />
      <Tab.Screen
        name="ProfileScreen"
        component={PlaceholderScreen}
        options={{ title: "Profile", tabBarIcon: ({ color }) => <Text style={{ color }}>P</Text> }}
      />
    </Tab.Navigator>
  );
}

export default function PassengerNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="PassengerTabs" component={PassengerTabs} />
      <Stack.Screen name="PassengerRouteList" component={PassengerRouteList} />
      <Stack.Screen name="AllBusesPage" component={AllBusesPage} />
      <Stack.Screen name="PassengerStopsTimeline" component={PassengerStopsTimeline} />
      <Stack.Screen name="PassengerLiveTracking" component={PassengerLiveTracking} />
      <Stack.Screen name="PassengerHomeScreen" component={PassengerHomeScreen} />
      <Stack.Screen name="DestinationSearchScreen" component={DestinationSearchScreen} />
      <Stack.Screen name="RouteResultsScreen" component={RouteResultsScreen} />
      <Stack.Screen name="RouteDetailsScreen" component={RouteDetailsScreen} />
      <Stack.Screen name="RaiseHandScreen" component={RaiseHandScreen} />
      <Stack.Screen name="AutoLiveTrackingScreen" component={AutoLiveTrackingScreen} />
      <Stack.Screen name="BikeBookingScreen" component={BikeBookingScreen} />
      <Stack.Screen name="BikeSearchingScreen" component={BikeSearchingScreen} />
      <Stack.Screen name="BikeTrackingScreen" component={BikeTrackingScreen} />
      <Stack.Screen name="JourneyHistoryScreen" component={JourneyHistoryScreen} />
    </Stack.Navigator>
  );
}
