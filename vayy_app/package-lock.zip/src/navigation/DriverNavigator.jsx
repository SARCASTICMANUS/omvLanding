import React from "react";
import { Text, View } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createStackNavigator } from "@react-navigation/stack";

import COLORS from "../shared/constants/colors";
import DriverRouteList from "../routes/screens/DriverRouteList";
import DriverLiveTracking from "../tracking/screens/DriverLiveTracking";
import DriverTripReview from "../routes/screens/DriverTripReview";
import BikeRequestScreen from "../bike/screens/BikeRequestScreen";
import DriverHomeScreen from "../driver/screens/DriverHomeScreen";
import DriverTrackingScreen from "../auto/screens/DriverTrackingScreen";
import DriverTripHistoryScreen from "../driver/screens/DriverTripHistoryScreen";
import PassengerAlertsScreen from "../handshake/screens/PassengerAlertsScreen";
import RouteCreationScreen from "../routes/screens/RouteCreationScreen";
import RouteLibraryScreen from "../routes/screens/RouteLibraryScreen";
import RouteSelectionScreen from "../routes/screens/RouteSelectionScreen";
import VehicleSelectionScreen from "../driver/screens/VehicleSelectionScreen";

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const PlaceholderScreen = ({ route }) => (
  <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
    <Text>{route.name}</Text>
  </View>
);

function DriverTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.textLight,
        tabBarStyle: {
          backgroundColor: COLORS.white,
          borderTopColor: COLORS.border,
          height: 60,
          paddingBottom: 10,
        },
      }}
    >
      <Tab.Screen name="DriverHomeScreen" component={DriverHomeScreen} options={{ title: "Console" }} />
      <Tab.Screen name="DriverRouteList" component={DriverRouteList} options={{ title: "Routes" }} />
      <Tab.Screen name="ProfileScreen" component={PlaceholderScreen} options={{ title: "Profile" }} />
    </Tab.Navigator>
  );
}

export default function DriverNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="DriverTabs" component={DriverTabs} />
      <Stack.Screen name="DriverTripReview" component={DriverTripReview} />
      <Stack.Screen name="DriverLiveTracking" component={DriverLiveTracking} />
      <Stack.Screen name="VehicleSelectionScreen" component={VehicleSelectionScreen} />
      <Stack.Screen name="RouteCreationScreen" component={RouteCreationScreen} />
      <Stack.Screen name="RouteLibraryScreen" component={RouteLibraryScreen} />
      <Stack.Screen name="RouteSelectionScreen" component={RouteSelectionScreen} />
      <Stack.Screen name="PassengerAlertsScreen" component={PassengerAlertsScreen} />
      <Stack.Screen name="BikeRequestScreen" component={BikeRequestScreen} />
      <Stack.Screen name="DriverTrackingScreen" component={DriverTrackingScreen} />
      <Stack.Screen name="DriverTripHistoryScreen" component={DriverTripHistoryScreen} />
    </Stack.Navigator>
  );
}
