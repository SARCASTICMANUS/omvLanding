import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  activeFlag: null,
  flagStatus: "IDLE",
  flagList: [],
};

const passengerFlagSlice = createSlice({
  name: "passengerFlag",
  initialState,
  reducers: {
    createFlag: (state, action) => {
      state.activeFlag = action.payload;
      state.flagStatus = action.payload?.status || "WAITING";
      state.flagList.unshift(action.payload);
    },
    setFlagStatus: (state, action) => {
      state.flagStatus = action.payload;
      if (state.activeFlag) state.activeFlag.status = action.payload;
    },
    setFlagList: (state, action) => {
      state.flagList = action.payload || [];
    },
    clearActiveFlag: (state) => {
      state.activeFlag = null;
      state.flagStatus = "IDLE";
    },
  },
});

export const { clearActiveFlag, createFlag, setFlagList, setFlagStatus } = passengerFlagSlice.actions;
export default passengerFlagSlice.reducer;

