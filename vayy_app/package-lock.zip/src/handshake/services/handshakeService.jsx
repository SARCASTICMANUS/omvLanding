const codes = new Map();

export const generateCode = async (rideId) => {
  const code = String(Math.floor(1000 + Math.random() * 9000));
  codes.set(rideId, code);
  return { rideId, code, method: "CODE", status: "PENDING" };
};

export const verifyCode = async (rideId, code) => {
  const isVerified = codes.get(rideId) === String(code);
  return { rideId, verified: isVerified, status: isVerified ? "VERIFIED" : "FAILED", method: "CODE" };
};

export const generateQR = async (rideId) => ({
  rideId,
  qrData: JSON.stringify({ rideId, issuedAt: Date.now(), type: "VAYY_BIKE_HANDSHAKE" }),
  method: "QR",
  status: "PENDING",
});

export const verifyQR = async (rideId, qrData) => {
  const parsed = typeof qrData === "string" ? JSON.parse(qrData) : qrData;
  const isVerified = parsed?.rideId === rideId && parsed?.type === "VAYY_BIKE_HANDSHAKE";
  return { rideId, verified: isVerified, status: isVerified ? "VERIFIED" : "FAILED", method: "QR" };
};

export default {
  generateCode,
  verifyCode,
  generateQR,
  verifyQR,
};

