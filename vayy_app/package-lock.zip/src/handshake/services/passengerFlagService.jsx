const flags = [];

export const createFlag = async (flagData) => {
  const flag = {
    ...flagData,
    flagId: flagData.flagId || `flag-${Date.now()}`,
    status: flagData.status || "WAITING",
    timestamp: flagData.timestamp || new Date().toISOString(),
  };
  flags.unshift(flag);
  return flag;
};

export const getFlagsOnRoute = async (routeId) =>
  flags.filter((flag) => flag.routeId === routeId && flag.status !== "CANCELLED");

export const updateFlagStatus = async (flagId, status) => {
  const flag = flags.find((item) => item.flagId === flagId);
  if (!flag) throw new Error("Passenger flag not found");
  flag.status = status;
  return flag;
};

export default {
  createFlag,
  getFlagsOnRoute,
  updateFlagStatus,
};

