import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  verificationCode: "",
  verificationStatus: "IDLE",
  methodUsed: null,
};

const handshakeSlice = createSlice({
  name: "handshake",
  initialState,
  reducers: {
    setVerificationCode: (state, action) => {
      state.verificationCode = action.payload;
      state.methodUsed = "CODE";
      state.verificationStatus = "PENDING";
    },
    setVerificationStatus: (state, action) => {
      state.verificationStatus = action.payload;
    },
    setMethodUsed: (state, action) => {
      state.methodUsed = action.payload;
    },
    resetHandshake: () => initialState,
  },
});

export const {
  resetHandshake,
  setMethodUsed,
  setVerificationCode,
  setVerificationStatus,
} = handshakeSlice.actions;

export default handshakeSlice.reducer;

