import React from "react";

import PassengerAlertCard from "../components/PassengerAlertCard";
import MvpScreen from "../../shared/components/common/MvpScreen";

export default function PassengerAlertsScreen() {
  return (
    <MvpScreen title="Passenger alerts" subtitle="Auto alerts are notification-only with no accept or decline action.">
      <PassengerAlertCard alert={{ passengerName: "Passenger waiting", stopName: "Campus Gate", distanceToStop: "600 m", estimatedFare: "INR 32" }} />
    </MvpScreen>
  );
}

