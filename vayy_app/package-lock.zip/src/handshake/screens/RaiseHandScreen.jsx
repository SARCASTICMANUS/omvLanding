import React, { useState } from "react";
import { useDispatch } from "react-redux";

import MvpScreen from "../../shared/components/common/MvpScreen";
import { createFlag as createFlagAction } from "../passengerFlagSlice";
import { createFlag } from "../services/passengerFlagService";

export default function RaiseHandScreen({ navigation }) {
  const dispatch = useDispatch();
  const [status, setStatus] = useState("Ready");

  const handleRaiseHand = async () => {
    const flag = await createFlag({
      passengerId: "current-passenger",
      routeId: "green-line-auto",
      stopId: "campus-gate",
      status: "WAITING",
    });
    dispatch(createFlagAction(flag));
    setStatus("WAITING");
  };

  return (
    <MvpScreen
      title="Raise hand"
      subtitle={`Flag status: ${status}. Drivers on this route receive a notification only.`}
      actions={[
        { label: "Raise hand now", onPress: handleRaiseHand },
        { label: "Track auto", onPress: () => navigation.navigate("AutoLiveTrackingScreen"), variant: "outline" },
      ]}
    />
  );
}

