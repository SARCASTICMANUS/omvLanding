import React from "react";
import { StyleSheet, Text, View } from "react-native";

import COLORS from "../../shared/constants/colors";
import SPACING from "../../shared/constants/spacing";
import VayyCard from "../../shared/components/common/VayyCard";

export default function PassengerAlertCard({ alert = {} }) {
  return (
    <VayyCard style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.title}>{alert.passengerName || "Passenger waiting"}</Text>
        <Text style={styles.status}>WAITING</Text>
      </View>
      <Text style={styles.text}>{alert.stopName || "Pickup stop"}</Text>
      <View style={styles.metrics}>
        <Text style={styles.metric}>{alert.distanceToStop || "600 m"} away</Text>
        <Text style={styles.metric}>{alert.estimatedFare || "INR 32"}</Text>
      </View>
    </VayyCard>
  );
}

const styles = StyleSheet.create({
  card: {
    gap: SPACING.sm,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: SPACING.base,
  },
  title: {
    color: COLORS.text,
    flex: 1,
    fontSize: 16,
    fontWeight: "800",
  },
  status: {
    color: COLORS.warning,
    fontSize: 12,
    fontWeight: "800",
  },
  text: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },
  metrics: {
    flexDirection: "row",
    gap: SPACING.sm,
  },
  metric: {
    color: COLORS.textMuted,
    fontSize: 13,
    fontWeight: "700",
  },
});

