import React, { useState } from "react";
import { StyleSheet, Text, TextInput } from "react-native";

import COLORS from "../../shared/constants/colors";
import SPACING from "../../shared/constants/spacing";
import VayyButton from "../../shared/components/common/VayyButton";
import VayyCard from "../../shared/components/common/VayyCard";

export default function VerificationCodeCard({ code, status = "PENDING", onSubmit }) {
  const [value, setValue] = useState("");

  return (
    <VayyCard style={styles.card}>
      <Text style={styles.title}>Verification code</Text>
      {code ? <Text style={styles.code}>{code}</Text> : null}
      <TextInput
        keyboardType="number-pad"
        maxLength={4}
        onChangeText={setValue}
        placeholder="0000"
        style={styles.input}
        value={value}
      />
      <VayyButton label="Verify" onPress={() => onSubmit?.(value)} fullWidth />
      <Text style={styles.status}>{status}</Text>
    </VayyCard>
  );
}

const styles = StyleSheet.create({
  card: {
    gap: SPACING.sm,
  },
  title: {
    color: COLORS.text,
    fontSize: 16,
    fontWeight: "800",
  },
  code: {
    color: COLORS.primary,
    fontSize: 28,
    fontWeight: "900",
    letterSpacing: 0,
  },
  input: {
    borderColor: COLORS.borderMedium,
    borderRadius: 8,
    borderWidth: 1,
    color: COLORS.text,
    fontSize: 20,
    fontWeight: "800",
    height: 48,
    paddingHorizontal: SPACING.base,
    textAlign: "center",
  },
  status: {
    color: COLORS.textMuted,
    fontSize: 13,
    fontWeight: "700",
  },
});
