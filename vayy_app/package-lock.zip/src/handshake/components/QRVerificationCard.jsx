import React from "react";
import { StyleSheet, Text, View } from "react-native";

import COLORS from "../../shared/constants/colors";
import SPACING from "../../shared/constants/spacing";
import VayyButton from "../../shared/components/common/VayyButton";
import VayyCard from "../../shared/components/common/VayyCard";

export default function QRVerificationCard({ qrData, role = "passenger", onScan }) {
  const isDriver = role === "driver";

  return (
    <VayyCard style={styles.card}>
      <Text style={styles.title}>{isDriver ? "Scan passenger QR" : "Passenger QR"}</Text>
      <View style={styles.qrBox}>
        <Text style={styles.qrText}>{qrData ? "QR" : "No QR"}</Text>
      </View>
      {isDriver ? <VayyButton label="Scan QR" onPress={() => onScan?.(qrData)} fullWidth /> : null}
    </VayyCard>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: "center",
    gap: SPACING.base,
  },
  title: {
    color: COLORS.text,
    fontSize: 16,
    fontWeight: "800",
  },
  qrBox: {
    alignItems: "center",
    aspectRatio: 1,
    backgroundColor: COLORS.background,
    borderColor: COLORS.borderMedium,
    borderRadius: 8,
    borderWidth: 1,
    justifyContent: "center",
    width: 160,
  },
  qrText: {
    color: COLORS.text,
    fontSize: 24,
    fontWeight: "900",
  },
});

