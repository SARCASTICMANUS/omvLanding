import React from "react";

import MvpScreen from "../../shared/components/common/MvpScreen";
import BikeTrackingMap from "../../tracking/components/BikeTrackingMap";

export default function BikeSearchingScreen({ navigation }) {
  return (
    <MvpScreen
      title="Searching"
      subtitle="Driver location stays hidden until a driver accepts the ride."
      actions={[{ label: "Simulate accepted driver", onPress: () => navigation.navigate("BikeTrackingScreen") }]}
    >
      <BikeTrackingMap searching accepted={false} />
    </MvpScreen>
  );
}

