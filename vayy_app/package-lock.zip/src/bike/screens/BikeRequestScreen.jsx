import React from "react";
import { useDispatch } from "react-redux";

import BikeRideRequestCard from "../components/BikeRideRequestCard";
import MvpScreen from "../../shared/components/common/MvpScreen";
import { acceptRequest, declineRequest } from "../services/bikeMatchingService";
import { assignBikeRequest, setRequestStatus } from "../bikeRequestSlice";

const sampleRequest = {
  requestId: "sample-bike-request",
  pickup: "Campus Gate",
  destination: "City Metro",
  distance: "4.2 km",
  eta: "9 min",
  estimatedFare: "INR 85",
};

export default function BikeRequestScreen({ navigation }) {
  const dispatch = useDispatch();

  const handleAccept = async () => {
    try {
      const request = await acceptRequest(sampleRequest.requestId);
      dispatch(assignBikeRequest(request));
    } catch {
      dispatch(assignBikeRequest(sampleRequest));
    }
    navigation.navigate("DriverTrackingScreen");
  };

  const handleDecline = async () => {
    try {
      await declineRequest(sampleRequest.requestId);
    } catch {
      // Sample request is intentionally local to the screen.
    }
    dispatch(setRequestStatus("DECLINED"));
  };

  return (
    <MvpScreen title="Bike requests" subtitle="Nearby Bike requests include accept and decline actions.">
      <BikeRideRequestCard request={sampleRequest} onAccept={handleAccept} onDecline={handleDecline} />
    </MvpScreen>
  );
}

