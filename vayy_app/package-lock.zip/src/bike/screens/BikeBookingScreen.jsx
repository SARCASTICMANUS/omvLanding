import React, { useState } from "react";
import { Text } from "react-native";
import { useDispatch } from "react-redux";

import MvpScreen from "../../shared/components/common/MvpScreen";
import { createRideRequest } from "../services/bikeMatchingService";
import { estimateFare } from "../../shared/services/fareEstimationService";
import { createBikeRequest } from "../bikeRequestSlice";

export default function BikeBookingScreen({ navigation }) {
  const dispatch = useDispatch();
  const [fare, setFare] = useState(null);

  const handleEstimate = async () => {
    setFare(await estimateFare(4200, "BIKE"));
  };

  const handleConfirm = async () => {
    const request = await createRideRequest({
      passengerId: "current-passenger",
      pickupLocation: { name: "Current location" },
      destination: { name: "City Metro" },
      estimatedFare: fare ? `${fare.currency} ${fare.amount}` : "INR 85",
    });
    dispatch(createBikeRequest(request));
    navigation.navigate("BikeSearchingScreen");
  };

  return (
    <MvpScreen
      title="Bike booking"
      subtitle="Enter pickup and destination, then confirm a nearby driver request."
      actions={[
        { label: "Estimate fare", onPress: handleEstimate, variant: "outline" },
        { label: "Confirm bike request", onPress: handleConfirm },
      ]}
    >
      {fare ? <Text>{fare.currency} {fare.amount}</Text> : null}
    </MvpScreen>
  );
}

