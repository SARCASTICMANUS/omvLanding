import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import VerificationCodeCard from "../../handshake/components/VerificationCodeCard";
import MvpScreen from "../../shared/components/common/MvpScreen";
import BikeTrackingMap from "../../tracking/components/BikeTrackingMap";
import { generateCode, verifyCode } from "../../handshake/services/handshakeService";
import { setVerificationCode, setVerificationStatus } from "../../handshake/handshakeSlice";

export default function BikeTrackingScreen() {
  const dispatch = useDispatch();
  const { verificationCode, verificationStatus } = useSelector((state) => state.handshake);
  const [rideId] = useState("active-bike-ride");

  useEffect(() => {
    generateCode(rideId).then((result) => dispatch(setVerificationCode(result.code)));
  }, [dispatch, rideId]);

  const handleVerify = async (code) => {
    const result = await verifyCode(rideId, code);
    dispatch(setVerificationStatus(result.status));
  };

  return (
    <MvpScreen title="Bike tracking" subtitle="Driver location and fare remain visible after acceptance.">
      <BikeTrackingMap accepted driverLocation={{ longitude: 77.6046, latitude: 12.9816 }} />
      <VerificationCodeCard code={verificationCode} status={verificationStatus} onSubmit={handleVerify} />
    </MvpScreen>
  );
}

