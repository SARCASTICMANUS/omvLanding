import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  activeRequest: null,
  nearbyRequests: [],
  requestStatus: "IDLE",
};

const bikeRequestSlice = createSlice({
  name: "bikeRequest",
  initialState,
  reducers: {
    createBikeRequest: (state, action) => {
      state.activeRequest = action.payload;
      state.requestStatus = action.payload?.status || "SEARCHING";
    },
    setNearbyRequests: (state, action) => {
      state.nearbyRequests = action.payload || [];
    },
    setRequestStatus: (state, action) => {
      state.requestStatus = action.payload;
      if (state.activeRequest) state.activeRequest.status = action.payload;
    },
    assignBikeRequest: (state, action) => {
      state.activeRequest = { ...state.activeRequest, ...action.payload, status: "ACCEPTED" };
      state.requestStatus = "ACCEPTED";
    },
    clearBikeRequest: (state) => {
      state.activeRequest = null;
      state.requestStatus = "IDLE";
    },
  },
});

export const {
  assignBikeRequest,
  clearBikeRequest,
  createBikeRequest,
  setNearbyRequests,
  setRequestStatus,
} = bikeRequestSlice.actions;

export default bikeRequestSlice.reducer;

