const requests = [];

export const createRideRequest = async (requestData) => {
  const request = {
    ...requestData,
    requestId: requestData.requestId || `bike-${Date.now()}`,
    status: "SEARCHING",
    createdAt: new Date().toISOString(),
  };
  requests.unshift(request);
  return request;
};

export const getNearbyRequests = async () =>
  requests.filter((request) => ["SEARCHING", "PENDING"].includes(request.status));

export const acceptRequest = async (requestId) => {
  const request = requests.find((item) => item.requestId === requestId);
  if (!request) throw new Error("Ride request not found");
  request.status = "ACCEPTED";
  request.acceptedAt = new Date().toISOString();
  return request;
};

export const declineRequest = async (requestId) => {
  const request = requests.find((item) => item.requestId === requestId);
  if (!request) throw new Error("Ride request not found");
  request.status = "DECLINED";
  return request;
};

export default {
  createRideRequest,
  getNearbyRequests,
  acceptRequest,
  declineRequest,
};

