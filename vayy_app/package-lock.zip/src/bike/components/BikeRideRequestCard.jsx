import React from "react";
import { StyleSheet, Text, View } from "react-native";

import COLORS from "../../shared/constants/colors";
import SPACING from "../../shared/constants/spacing";
import VayyButton from "../../shared/components/common/VayyButton";
import VayyCard from "../../shared/components/common/VayyCard";

export default function BikeRideRequestCard({ request = {}, onAccept, onDecline }) {
  return (
    <VayyCard style={styles.card}>
      <Text style={styles.title}>Bike ride request</Text>
      <Text style={styles.path}>
        {request.pickupLocation?.name || request.pickup || "Pickup"} to{" "}
        {request.destination?.name || request.destination || "Destination"}
      </Text>
      <View style={styles.metrics}>
        <Text style={styles.metric}>{request.distance || "3.8 km"}</Text>
        <Text style={styles.metric}>{request.eta || "8 min"}</Text>
        <Text style={styles.metric}>{request.estimatedFare || "INR 72"}</Text>
      </View>
      <View style={styles.actions}>
        <VayyButton label="Decline" onPress={onDecline} variant="outline" size="sm" />
        <VayyButton label="Accept" onPress={onAccept} size="sm" />
      </View>
    </VayyCard>
  );
}

const styles = StyleSheet.create({
  card: {
    gap: SPACING.sm,
  },
  title: {
    color: COLORS.text,
    fontSize: 16,
    fontWeight: "800",
  },
  path: {
    color: COLORS.textSecondary,
    fontSize: 14,
    fontWeight: "700",
  },
  metrics: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: SPACING.sm,
  },
  metric: {
    backgroundColor: COLORS.background,
    borderRadius: 8,
    color: COLORS.textMuted,
    fontSize: 13,
    fontWeight: "700",
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
  },
  actions: {
    flexDirection: "row",
    gap: SPACING.sm,
    justifyContent: "flex-end",
  },
});

