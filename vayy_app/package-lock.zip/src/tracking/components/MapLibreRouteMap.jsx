import React, { useMemo } from "react";
import { NativeModules, StyleSheet, Text, View } from "react-native";

import COLORS from "../../shared/constants/colors";

let cachedMapLibreGL;
let didTryLoadMapLibre = false;

const getMapLibreGL = () => {
  if (didTryLoadMapLibre) return cachedMapLibreGL;
  didTryLoadMapLibre = true;

  if (!NativeModules?.MLRNCameraModule) {
    cachedMapLibreGL = null;
    return cachedMapLibreGL;
  }

  try {
    const module = require("@maplibre/maplibre-react-native");
    cachedMapLibreGL = module.default || module;
    cachedMapLibreGL?.setAccessToken?.(null);
  } catch {
    cachedMapLibreGL = null;
  }

  return cachedMapLibreGL;
};

const osmStyle = {
  version: 8,
  sources: {
    osm: {
      type: "raster",
      tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
      tileSize: 256,
      attribution: "OpenStreetMap contributors",
    },
  },
  layers: [{ id: "osm", type: "raster", source: "osm" }],
};

const fallbackCenter = [77.5946, 12.9716];

const normalizePoint = (point) => {
  const longitude = Number(point?.longitude ?? point?.lng ?? point?.lon);
  const latitude = Number(point?.latitude ?? point?.lat);
  return Number.isFinite(longitude) && Number.isFinite(latitude) ? [longitude, latitude] : null;
};

const pointFeature = (id, point, role) => ({
  type: "Feature",
  id,
  properties: { role },
  geometry: { type: "Point", coordinates: point },
});

export default function MapLibreRouteMap({
  routeCoordinates = [],
  stops = [],
  vehiclePosition,
  passengerPosition,
  showDriver = true,
  searching = false,
}) {
  const routeLine = routeCoordinates.length
    ? routeCoordinates
    : [
        [77.5946, 12.9716],
        [77.6046, 12.9816],
        [77.6146, 12.9866],
      ];
  const vehiclePoint = normalizePoint(vehiclePosition) || routeLine[1];
  const passengerPoint = normalizePoint(passengerPosition) || routeLine[0];
  const stopFeatures = stops
    .map((stop, index) => normalizePoint(stop) || routeLine[index % routeLine.length])
    .map((point, index) => pointFeature(`stop-${index}`, point, "stop"));
  const features = [
    ...stopFeatures,
    pointFeature("passenger", passengerPoint, "passenger"),
    ...(showDriver ? [pointFeature("vehicle", vehiclePoint, "vehicle")] : []),
  ];
  const MapLibreGL = useMemo(() => getMapLibreGL(), []);

  if (!MapLibreGL) {
    return (
      <View style={styles.container}>
        <View style={styles.fallbackMap}>
          <View style={styles.fallbackLine} />
          <View style={[styles.fallbackPoint, styles.fallbackPassengerPoint]} />
          {showDriver ? <View style={[styles.fallbackPoint, styles.fallbackVehiclePoint]} /> : null}
          <View style={styles.fallbackStop} />
          <Text style={styles.fallbackText}>MapLibre native module unavailable</Text>
        </View>
        {searching ? (
          <View style={styles.searchingBadge}>
            <Text style={styles.searchingText}>Searching</Text>
          </View>
        ) : null}
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapLibreGL.MapView style={styles.map} styleJSON={JSON.stringify(osmStyle)}>
        <MapLibreGL.Camera centerCoordinate={vehiclePoint || fallbackCenter} zoomLevel={13} />
        <MapLibreGL.ShapeSource
          id="route-source"
          shape={{
            type: "Feature",
            geometry: { type: "LineString", coordinates: routeLine },
            properties: {},
          }}
        >
          <MapLibreGL.LineLayer id="route-line" style={styles.routeLine} />
        </MapLibreGL.ShapeSource>
        <MapLibreGL.ShapeSource id="points-source" shape={{ type: "FeatureCollection", features }}>
          <MapLibreGL.CircleLayer id="points" style={styles.points} />
        </MapLibreGL.ShapeSource>
      </MapLibreGL.MapView>
      {searching ? (
        <View style={styles.searchingBadge}>
          <Text style={styles.searchingText}>Searching</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.background,
    borderColor: COLORS.borderMedium,
    borderRadius: 8,
    borderWidth: 1,
    height: 260,
    overflow: "hidden",
  },
  map: {
    flex: 1,
  },
  routeLine: {
    lineColor: COLORS.primary,
    lineWidth: 4,
    lineOpacity: 0.9,
  },
  points: {
    circleColor: [
      "match",
      ["get", "role"],
      "vehicle",
      COLORS.primary,
      "passenger",
      COLORS.warning,
      COLORS.black,
    ],
    circleRadius: ["match", ["get", "role"], "vehicle", 8, "passenger", 7, 5],
    circleStrokeColor: COLORS.white,
    circleStrokeWidth: 2,
  },
  searchingBadge: {
    backgroundColor: COLORS.white,
    borderRadius: 8,
    bottom: 12,
    left: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    position: "absolute",
  },
  searchingText: {
    color: COLORS.text,
    fontSize: 12,
    fontWeight: "800",
  },
  fallbackMap: {
    flex: 1,
    justifyContent: "center",
    padding: 24,
  },
  fallbackLine: {
    backgroundColor: COLORS.primary,
    borderRadius: 999,
    height: 5,
    opacity: 0.8,
    transform: [{ rotate: "-18deg" }],
    width: "100%",
  },
  fallbackPoint: {
    borderColor: COLORS.white,
    borderRadius: 999,
    borderWidth: 3,
    height: 18,
    position: "absolute",
    width: 18,
  },
  fallbackPassengerPoint: {
    backgroundColor: COLORS.warning,
    bottom: 72,
    left: 38,
  },
  fallbackVehiclePoint: {
    backgroundColor: COLORS.primary,
    right: 42,
    top: 74,
  },
  fallbackStop: {
    backgroundColor: COLORS.black,
    borderColor: COLORS.white,
    borderRadius: 999,
    borderWidth: 3,
    height: 14,
    left: "50%",
    position: "absolute",
    top: "50%",
    width: 14,
  },
  fallbackText: {
    alignSelf: "center",
    backgroundColor: COLORS.white,
    borderRadius: 8,
    bottom: 14,
    color: COLORS.textMuted,
    fontSize: 12,
    fontWeight: "800",
    paddingHorizontal: 10,
    paddingVertical: 7,
    position: "absolute",
  },
});
