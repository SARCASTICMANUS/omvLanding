import React from "react";

import MapLibreRouteMap from "./MapLibreRouteMap";

export default function AutoTrackingMap({ routeCoordinates, stops, vehiclePosition }) {
  return (
    <MapLibreRouteMap
      routeCoordinates={routeCoordinates}
      stops={stops}
      vehiclePosition={vehiclePosition}
      showDriver
    />
  );
}

