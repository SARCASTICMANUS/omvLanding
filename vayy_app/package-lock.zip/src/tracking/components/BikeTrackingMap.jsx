import React from "react";

import MapLibreRouteMap from "./MapLibreRouteMap";

export default function BikeTrackingMap({
  accepted = false,
  driverLocation,
  passengerLocation,
  routeCoordinates,
  searching = false,
}) {
  return (
    <MapLibreRouteMap
      routeCoordinates={routeCoordinates}
      vehiclePosition={driverLocation}
      passengerPosition={passengerLocation}
      showDriver={accepted}
      searching={searching || !accepted}
    />
  );
}

