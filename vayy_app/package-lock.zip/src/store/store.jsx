import { configureStore } from "@reduxjs/toolkit";

import {
  logout,
  refreshTokenSuccess,
  default as authReducer,
} from "../auth/authSlice";
import { configureAuthHandlers } from "../shared/lib/api";
import bikeRequestReducer from "../bike/bikeRequestSlice";
import handshakeReducer from "../handshake/handshakeSlice";
import passengerFlagReducer from "../handshake/passengerFlagSlice";
import routeReducer from "../routes/routeSlice";
import routeLibraryReducer from "../routes/routeLibrarySlice";
import vehicleModeReducer from "./slices/vehicleModeSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    bikeRequest: bikeRequestReducer,
    handshake: handshakeReducer,
    passengerFlag: passengerFlagReducer,
    route: routeReducer,
    routeLibrary: routeLibraryReducer,
    vehicleMode: vehicleModeReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

configureAuthHandlers({
  onRefreshToken: (payload) => store.dispatch(refreshTokenSuccess(payload)),
  onUnauthorized: () => store.dispatch(logout()),
});

export default store;
