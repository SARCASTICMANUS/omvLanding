import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  selectedMode: "AUTO",
};

const vehicleModeSlice = createSlice({
  name: "vehicleMode",
  initialState,
  reducers: {
    setVehicleMode: (state, action) => {
      const mode = String(action.payload).toUpperCase();
      state.selectedMode = mode === "BIKE" ? "BIKE" : "AUTO";
    },
  },
});

export const { setVehicleMode } = vehicleModeSlice.actions;
export default vehicleModeSlice.reducer;

